export enum LAYOUT_OPTIONS {
  MODERN = 'modern',
  MINIMAL = 'minimal',
  RETRO = 'retro',
  CLASSIC = 'classic',
}
