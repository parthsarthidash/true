export default function CreateNftForm() {
  return <div></div>;
}
