interface Props {}

function Badge(props: Props) {
  return <span {...props} />;
}

export default Badge;

// display: flex;
// flex-direction: row;
// align-items: flex-start;
// padding: 8px 12px;

// position: absolute;
// width: 125px;
// height: 31px;
// left: 515px;
// top: 90px;

// background: #373737;
// border: 1px solid #474747;
// box-sizing: border-box;
// border-radius: 100px;
