import React from 'react';

function PopoverContent() {
  return (
    <div className="p-2">
      The total market value of a cryptocurrencys circulating supply. It is
      analogous to the free-float capitalization in the stock market.
    </div>
  );
}

export default PopoverContent;
