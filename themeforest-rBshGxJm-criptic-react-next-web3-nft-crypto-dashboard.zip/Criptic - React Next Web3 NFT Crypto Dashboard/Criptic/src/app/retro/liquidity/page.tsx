import LiquidityPage from '@/app/shared/liquidity';

export default function LiquidityPageRetro() {
  return <LiquidityPage />;
}
