import CreateNFTRetro from '@/components/create-nft/create-nft-retro';

export default function CreateNFTPageRetro() {
  return <CreateNFTRetro />;
}
