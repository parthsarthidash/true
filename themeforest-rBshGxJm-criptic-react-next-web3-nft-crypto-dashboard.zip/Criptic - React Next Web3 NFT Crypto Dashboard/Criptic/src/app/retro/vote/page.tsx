import VotePage from '@/app/shared/vote';

export default function VotePageRetro() {
  return <VotePage />;
}
