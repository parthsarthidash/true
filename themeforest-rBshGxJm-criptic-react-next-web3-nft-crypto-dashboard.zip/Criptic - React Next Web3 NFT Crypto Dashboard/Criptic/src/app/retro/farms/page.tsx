import FarmsPage from '@/components/farms/farms';

export default function FarmsPageRetro() {
  return <FarmsPage />;
}
