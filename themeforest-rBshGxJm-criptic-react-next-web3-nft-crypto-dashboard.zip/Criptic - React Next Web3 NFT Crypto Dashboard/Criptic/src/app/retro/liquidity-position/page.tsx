import LiquidityPositionPage from '@/app/shared/liquidity-position';

export default function LiquidityPositionPageRetro() {
  return <LiquidityPositionPage />;
}
