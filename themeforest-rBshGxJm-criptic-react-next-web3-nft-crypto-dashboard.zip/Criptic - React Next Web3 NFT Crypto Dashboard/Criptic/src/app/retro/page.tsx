import RetroScreen from '@/components/screens/retro-screen';

export default function IndexPageRetro() {
  return <RetroScreen />;
}
