import CoinSinglePrice from '@/app/shared/coin-details';

export default function SinglePriceMinimal() {
  return <CoinSinglePrice />;
}
