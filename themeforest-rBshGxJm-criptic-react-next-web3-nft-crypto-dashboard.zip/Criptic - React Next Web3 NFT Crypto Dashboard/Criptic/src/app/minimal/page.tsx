import MinimalScreen from '@/components/screens/minimal-screen';

export default function IndexPageMinimal() {
  return <MinimalScreen />;
}
