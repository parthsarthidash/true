import ProposalsPage from '@/app/shared/proposals';

export default function ProposalsPageMinimal() {
  return <ProposalsPage />;
}
