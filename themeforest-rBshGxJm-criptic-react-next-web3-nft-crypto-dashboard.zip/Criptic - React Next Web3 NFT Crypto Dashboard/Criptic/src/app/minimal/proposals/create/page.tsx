import CreateProposalsPage from '@/app/shared/create-proposals';

export default function CreateProposalsPageMinimal() {
  return <CreateProposalsPage />;
}
