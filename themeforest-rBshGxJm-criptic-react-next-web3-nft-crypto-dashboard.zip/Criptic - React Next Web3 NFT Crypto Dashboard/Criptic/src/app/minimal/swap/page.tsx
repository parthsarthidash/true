import SwapPage from '@/app/shared/swap';

export default function SwapPageMinimal() {
  return <SwapPage />;
}
