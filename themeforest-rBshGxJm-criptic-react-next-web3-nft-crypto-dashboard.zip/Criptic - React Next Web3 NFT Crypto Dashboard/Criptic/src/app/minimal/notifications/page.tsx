import NotificationPage from '@/app/shared/notifications';

export default function NotificationPageMinimal() {
  return <NotificationPage />;
}
