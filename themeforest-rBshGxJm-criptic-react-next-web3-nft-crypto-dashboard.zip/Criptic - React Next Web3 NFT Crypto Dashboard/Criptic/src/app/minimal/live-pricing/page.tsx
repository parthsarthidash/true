import LiveDemo from '@/app/shared/live-pricing';

export default function LiveDemoMinimal() {
  return <LiveDemo />;
}
