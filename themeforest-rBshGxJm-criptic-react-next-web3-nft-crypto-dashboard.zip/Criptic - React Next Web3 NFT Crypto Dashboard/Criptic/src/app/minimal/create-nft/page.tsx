import CreateNFT from '@/components/create-nft/create-nft';

export default function CreateNFTPageMinimal() {
  return <CreateNFT />;
}
