import LiquidityPositionPage from '@/app/shared/liquidity-position';

export default function LiquidityPositionPageMinimal() {
  return <LiquidityPositionPage />;
}
