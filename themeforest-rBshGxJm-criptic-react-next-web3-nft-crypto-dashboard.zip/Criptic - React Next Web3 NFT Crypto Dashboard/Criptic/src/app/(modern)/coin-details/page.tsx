import CoinSinglePrice from '@/app/shared/coin-details';

export default function SinglePriceModern() {
  return <CoinSinglePrice />;
}
