import LiquidityPage from '@/app/shared/liquidity';

export default function LiquidityPageModern() {
  return <LiquidityPage />;
}
