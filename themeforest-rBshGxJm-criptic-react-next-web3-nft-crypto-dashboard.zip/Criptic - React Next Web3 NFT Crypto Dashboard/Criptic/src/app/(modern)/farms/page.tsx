import FarmsPage from '@/components/farms/farms';

export default function FarmsPageModern() {
  return <FarmsPage />;
}
