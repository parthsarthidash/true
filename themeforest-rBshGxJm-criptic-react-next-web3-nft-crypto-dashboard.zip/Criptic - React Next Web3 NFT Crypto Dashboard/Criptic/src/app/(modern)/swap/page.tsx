import SwapPage from '@/app/shared/swap';

export default function SwapPageModern() {
  return <SwapPage />;
}
