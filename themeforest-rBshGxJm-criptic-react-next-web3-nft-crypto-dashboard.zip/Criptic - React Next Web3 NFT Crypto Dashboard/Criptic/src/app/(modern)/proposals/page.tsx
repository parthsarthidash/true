import ProposalsPage from '@/app/shared/proposals';

export default function ProposalsPageModern() {
  return <ProposalsPage />;
}
