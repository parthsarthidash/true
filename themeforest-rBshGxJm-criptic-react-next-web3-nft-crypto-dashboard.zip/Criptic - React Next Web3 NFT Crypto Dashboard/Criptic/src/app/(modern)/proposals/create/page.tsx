import CreateProposalsPage from '@/app/shared/create-proposals';

export default function CreateProposalsPageModern() {
  return <CreateProposalsPage />;
}
