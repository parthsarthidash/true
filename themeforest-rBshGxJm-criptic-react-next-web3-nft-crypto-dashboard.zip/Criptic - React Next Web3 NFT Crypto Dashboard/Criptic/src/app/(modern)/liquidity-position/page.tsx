import LiquidityPositionPage from '@/app/shared/liquidity-position';

export default function LiquidityPositionPageModern() {
  return <LiquidityPositionPage />;
}
