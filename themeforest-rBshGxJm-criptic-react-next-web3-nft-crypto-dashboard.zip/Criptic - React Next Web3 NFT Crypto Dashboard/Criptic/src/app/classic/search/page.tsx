import Search from '@/components/search/search';

export default function SearchPageClassic() {
  return <Search />;
}
