import LiquidityPage from '@/app/shared/liquidity';

export default function LiquidityPageClassic() {
  return <LiquidityPage />;
}
