import NotificationPage from '@/app/shared/notifications';

export default function NotificationPageClassic() {
  return <NotificationPage />;
}
