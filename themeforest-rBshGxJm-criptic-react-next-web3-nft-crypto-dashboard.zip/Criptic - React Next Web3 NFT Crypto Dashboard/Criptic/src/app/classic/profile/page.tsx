import AuthorProfilePage from '@/app/shared/profile';

export default function AuthorProfilePageClassic() {
  return <AuthorProfilePage />;
}
